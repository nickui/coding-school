$("#growBtn").on("click", function() {
    // Change box height.
    $("#box").animate({height:"+=35px"}, "fast");
})

$("#makeBlue").on("click", function() {
    // Change box color.
    $("#box").css("background-color", "blue");
})

$("#makeO").on("click", function() {
    // Change box color.
    $("#box").css("opacity", "0.5");
})

$("#resetBtn").on("click", function() {
    // Change box color.
    $("#box").css("opacity", "1")
    $("#box").css("color", "orange")
    $("#box").css("height", "150px");
})